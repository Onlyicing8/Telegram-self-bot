"""
.preview <code> / .retrieve <code> / .r <code> — Show stored metadata for a saved item.
.send <code>                                 — Forward the saved asset into the current chat.
.preview / .retrieve / .r / .send (no args)  — Inline panel with input button.

All three preview aliases share one execution path. No duplicated logic.

Inline Mode:
  - Commands without args trigger inline panels with input buttons.
  - Input handlers listen for the owner's next message, then execute.
  - The inline message is edited with the result after execution.
  - Commands with args still work as edit-in-place (backward compat).
"""
import asyncio
import logging
from telethon import events
from backend.bot.handlers.guard import is_owner
from backend.db import client as db_client
from backend.diagnostics import record_event
from backend.helper import (
    InlinePanelBuilder,
    register_panel,
    register_inline_builder,
    register_input,
    send_inline_panel,
)
from backend.helper.client import get_client

logger = logging.getLogger(__name__)


def _format_preview(row: dict) -> str:
    size_str = f"{row['file_size'] / 1024:.1f} KB" if row.get("file_size") else "—"
    tags = " ".join(row.get("tags") or [])
    code = row.get("short_code") or row.get("save_code") or "—"
    return (
        f"**Save Code:** `{code}`\n"
        f"**Type:** {row.get('save_type', '—').title()}\n"
        f"**Media:** {row.get('media_type', '—')}\n"
        f"**MIME:** `{row.get('mime_type') or '—'}`\n"
        f"**Size:** {size_str}\n"
        f"**Sender:** {row.get('sender_name') or '—'}\n"
        f"**Origin Chat:** `{row.get('origin_chat_id')}`\n"
        f"**Origin Msg:** `{row.get('origin_msg_id')}`\n"
        f"**Saved At:** {str(row.get('created_at', '—'))[:19]}\n"
        f"**Tags:** {tags or '—'}"
    )


async def _do_preview(client, owner_id: int, save_code: str) -> str:
    t0 = asyncio.get_event_loop().time()
    try:
        row = db_client.query_save(save_code)
        record_event("database", "query_save", (asyncio.get_event_loop().time() - t0) * 1000, "SUCCESS")
    except Exception as exc:
        logger.error("preview db error: %s", exc)
        record_event("database", "query_save", 0, "ERROR", str(exc))
        return f"❌ DB error: {exc}"
    if not row:
        return f"❌ No item found for `{save_code}`"
    await db_client.log(owner_id, "INFO", f"Preview {save_code}", {"save_code": save_code})
    return _format_preview(row)


async def _do_send(client, owner_id: int, save_code: str, target_chat: int) -> str:
    t0 = asyncio.get_event_loop().time()
    try:
        row = db_client.query_save(save_code)
        record_event("database", "query_save", (asyncio.get_event_loop().time() - t0) * 1000, "SUCCESS")
    except Exception as exc:
        logger.error("send db error: %s", exc)
        record_event("database", "query_save", 0, "ERROR", str(exc))
        return f"❌ DB error: {exc}"
    if not row:
        return f"❌ No item found for `{save_code}`"
    saved_chat_id = row.get("saved_chat_id")
    saved_msg_id = row.get("saved_msg_id")
    if not saved_chat_id or not saved_msg_id:
        return "❌ Saved location data is missing for this entry."
    t1 = asyncio.get_event_loop().time()
    try:
        await client.forward_messages(target_chat, saved_msg_id, saved_chat_id)
        record_event("retrieve", "forward_messages", (asyncio.get_event_loop().time() - t1) * 1000, "SUCCESS")
    except Exception as exc:
        logger.error("send forward failed: %s", exc)
        record_event("retrieve", "forward_messages", 0, "ERROR", str(exc))
        return f"❌ Forward failed: {exc}"
    await db_client.log(owner_id, "INFO", f"Sent {save_code} to {target_chat}", {"save_code": save_code, "target_chat": target_chat})
    return f"✅ Sent `{save_code}` to this chat."


async def _preview_input_handler(text: str, chat_id: int, msg_id: int, inline_chat_id: int, inline_msg_id: int) -> None:
    from backend.helper.inline_engine import _self_client, _owner_id
    client = _self_client
    owner_id = _owner_id
    save_code = text.strip().upper()
    result = await _do_preview(client, owner_id, save_code)
    builder = InlinePanelBuilder()
    builder.add_row("Close", "panel:help:close")
    try:
        await client.edit_message(inline_chat_id, inline_msg_id, result, buttons=builder.build())
    except Exception as exc:
        logger.warning("preview inline edit failed: %s", exc)
    try:
        await client.delete_messages(chat_id, [msg_id])
    except Exception:
        pass


async def _send_input_handler(text: str, chat_id: int, msg_id: int, inline_chat_id: int, inline_msg_id: int) -> None:
    from backend.helper.inline_engine import _self_client, _owner_id
    client = _self_client
    owner_id = _owner_id
    save_code = text.strip().upper()
    result = await _do_send(client, owner_id, save_code, chat_id)
    builder = InlinePanelBuilder()
    builder.add_row("Close", "panel:help:close")
    try:
        await client.edit_message(inline_chat_id, inline_msg_id, result, buttons=builder.build())
    except Exception as exc:
        logger.warning("send inline edit failed: %s", exc)
    try:
        await client.delete_messages(chat_id, [msg_id])
    except Exception:
        pass


async def _preview_inline_builder(event, extra: str) -> list:
    from telethon.tl import types
    text = "**Preview**\n\nTap the button below, then type a save code."
    builder = InlinePanelBuilder()
    builder.add_row("📝 Enter Save Code", "input:preview:code")
    builder.add_row("Close", "panel:help:close")
    buttons = builder.build()
    msg = types.InputBotInlineMessageTextAuto(message=text, reply_markup=types.ReplyInlineMarkup(rows=buttons) if buttons else None)
    result = types.InputBotInlineResult(id="0", type="article", title="Preview Saved Item", send_message=msg)
    return [result]


async def _send_inline_builder(event, extra: str) -> list:
    from telethon.tl import types
    text = "**Send**\n\nTap the button below, then type a save code."
    builder = InlinePanelBuilder()
    builder.add_row("📝 Enter Save Code", "input:send:code")
    builder.add_row("Close", "panel:help:close")
    buttons = builder.build()
    msg = types.InputBotInlineMessageTextAuto(message=text, reply_markup=types.ReplyInlineMarkup(rows=buttons) if buttons else None)
    result = types.InputBotInlineResult(id="0", type="article", title="Send Saved Item", send_message=msg)
    return [result]


def register(client, owner_id: int):
    register_panel("preview", _preview_inline_builder)
    register_panel("send", _send_inline_builder)
    register_inline_builder("preview", _preview_inline_builder)
    register_inline_builder("send", _send_inline_builder)
    register_input("preview", "code", _preview_input_handler)
    register_input("send", "code", _send_input_handler)

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.(?:preview|retrieve|r)\s+(\S+)$"))
    async def preview(event):
        if not is_owner(event, owner_id):
            return
        save_code = event.pattern_match.group(1).upper()
        result = await _do_preview(client, owner_id, save_code)
        await event.edit(result)

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.(?:preview|retrieve|r)$"))
    async def preview_panel(event):
        if not is_owner(event, owner_id):
            return
        helper = get_client()
        if helper is None:
            await event.edit("⚠️ Inline mode requires the helper bot (BOT_TOKEN).")
            return
        try:
            await event.delete()
            await send_inline_panel(client, event.chat_id, "preview")
        except Exception as exc:
            logger.warning("preview inline send failed: %s", exc)

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.send\s+(\S+)$"))
    async def send_cmd(event):
        if not is_owner(event, owner_id):
            return
        save_code = event.pattern_match.group(1).upper()
        result = await _do_send(client, owner_id, save_code, event.chat_id)
        if result.startswith("✅"):
            await event.delete()
        else:
            await event.edit(result)

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.send$"))
    async def send_panel(event):
        if not is_owner(event, owner_id):
            return
        helper = get_client()
        if helper is None:
            await event.edit("⚠️ Inline mode requires the helper bot (BOT_TOKEN).")
            return
        try:
            await event.delete()
            await send_inline_panel(client, event.chat_id, "send")
        except Exception as exc:
            logger.warning("send inline send failed: %s", exc)
