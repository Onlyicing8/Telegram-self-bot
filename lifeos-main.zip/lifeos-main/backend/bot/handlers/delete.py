"""
.del <n>         — Delete the last n outgoing messages in this chat.
.del id <msgid>  — Delete all messages from <msgid> forward in this chat.
.del <code>      — Delete a saved item: Telegram message + DB row.
.del             — Inline panel with three input options.

Edit-first policy: error feedback edits the trigger message.
Successful deletion silently removes all targeted messages (including the command).

Inline Mode:
  - .del (no args) triggers an inline panel with three input buttons.
  - Input handlers listen for the owner's next message, then execute.
  - The inline message is edited with the result after execution.
  - .del <n> / .del id <msgid> / .del <code> still work as edit-in-place.
"""
import asyncio
import logging
from telethon import events
from backend.bot.handlers.guard import is_owner
from backend.db import client as db_client
from backend.diagnostics import record_event
from backend.helper import (
    InlinePanelBuilder,
    register_panel,
    register_inline_builder,
    register_input,
    send_inline_panel,
)
from backend.helper.client import get_client

logger = logging.getLogger(__name__)

_BATCH = 100


async def _do_del_n(client, chat_id: int, n: int) -> str:
    if n < 1 or n > 500:
        return "⚠️ n must be between 1 and 500."
    t0 = asyncio.get_event_loop().time()
    try:
        msg_ids = []
        async for msg in client.iter_messages(chat_id, limit=n + 5, from_user="me"):
            msg_ids.append(msg.id)
            if len(msg_ids) >= n:
                break
        if msg_ids:
            await client.delete_messages(chat_id, msg_ids[:n])
        record_event("delete", "del n", (asyncio.get_event_loop().time() - t0) * 1000, "SUCCESS")
        return f"🗑 Deleted `{len(msg_ids[:n])}` messages."
    except Exception as exc:
        logger.error("del n failed: %s", exc)
        record_event("delete", "del n", 0, "ERROR", str(exc))
        return f"❌ Delete failed: {exc}"


async def _do_del_id(client, chat_id: int, start_id: int) -> str:
    t0 = asyncio.get_event_loop().time()
    try:
        msg_ids = []
        async for msg in client.iter_messages(chat_id, min_id=start_id - 1):
            msg_ids.append(msg.id)
            if len(msg_ids) >= _BATCH:
                await client.delete_messages(chat_id, msg_ids)
                msg_ids = []
        if msg_ids:
            await client.delete_messages(chat_id, msg_ids)
        record_event("delete", "del id", (asyncio.get_event_loop().time() - t0) * 1000, "SUCCESS")
        return f"🗑 Deleted messages from ID `{start_id}` forward."
    except Exception as exc:
        logger.error("del id failed: %s", exc)
        record_event("delete", "del id", 0, "ERROR", str(exc))
        return f"❌ Delete failed: {exc}"


async def _do_del_code(client, owner_id: int, code: str) -> str:
    t0 = asyncio.get_event_loop().time()
    try:
        row = db_client.query_save(code)
        record_event("database", "query_save", (asyncio.get_event_loop().time() - t0) * 1000, "SUCCESS")
    except Exception as exc:
        logger.error("del save_code DB query failed: %s", exc)
        record_event("database", "query_save", 0, "ERROR", str(exc))
        return f"❌ DB error: {exc}"
    if not row:
        return f"❌ No saved item found for `{code}`"
    saved_chat_id = row.get("saved_chat_id")
    saved_msg_id = row.get("saved_msg_id")
    display = row.get("short_code") or row.get("save_code") or code
    tg_deleted = False
    tg_error = None
    if saved_chat_id and saved_msg_id:
        try:
            await client.delete_messages(saved_chat_id, [saved_msg_id])
            tg_deleted = True
        except Exception as exc:
            tg_error = exc
            logger.warning("del %s: Telegram deletion failed: %s", code, exc)
    else:
        tg_deleted = True
    db_deleted = False
    db_error = None
    try:
        removed = db_client.delete_save_row(owner_id, code)
        db_deleted = removed is not None
    except Exception as exc:
        db_error = exc
        logger.error("del %s: DB deletion failed: %s", code, exc)
    if tg_deleted and db_deleted:
        result = f"🗑 Deleted `{display}`"
    elif tg_deleted and not db_deleted:
        result = f"⚠️ `{display}`: Telegram message deleted, but DB row removal failed: {db_error}"
    elif not tg_deleted and db_deleted:
        if tg_error:
            result = f"⚠️ `{display}`: DB row deleted, but Telegram message deletion failed: {tg_error}"
        else:
            result = f"🗑 Deleted `{display}` (Telegram message was already missing)"
    else:
        result = f"❌ `{display}`: Both Telegram and DB deletion failed. TG: {tg_error}, DB: {db_error}"
    await db_client.log(
        owner_id,
        "INFO" if (tg_deleted and db_deleted) else "ERROR",
        f"Delete {code}: tg={'ok' if tg_deleted else 'fail'}, db={'ok' if db_deleted else 'fail'}",
        {"save_code": code, "tg_error": str(tg_error) if tg_error else None},
    )
    return result


async def _del_n_input_handler(text: str, chat_id: int, msg_id: int, inline_chat_id: int, inline_msg_id: int) -> None:
    from backend.helper.inline_engine import _self_client
    client = _self_client
    n_str = text.strip()
    if not n_str.isdigit():
        result = "⚠️ Please enter a number between 1 and 500."
    else:
        result = await _do_del_n(client, chat_id, int(n_str))
    builder = InlinePanelBuilder()
    builder.add_row("Close", "panel:help:close")
    try:
        await client.edit_message(inline_chat_id, inline_msg_id, result, buttons=builder.build())
    except Exception as exc:
        logger.warning("del n inline edit failed: %s", exc)
    try:
        await client.delete_messages(chat_id, [msg_id])
    except Exception:
        pass


async def _del_id_input_handler(text: str, chat_id: int, msg_id: int, inline_chat_id: int, inline_msg_id: int) -> None:
    from backend.helper.inline_engine import _self_client
    client = _self_client
    id_str = text.strip()
    if not id_str.isdigit():
        result = "⚠️ Please enter a valid message ID."
    else:
        result = await _do_del_id(client, chat_id, int(id_str))
    builder = InlinePanelBuilder()
    builder.add_row("Close", "panel:help:close")
    try:
        await client.edit_message(inline_chat_id, inline_msg_id, result, buttons=builder.build())
    except Exception as exc:
        logger.warning("del id inline edit failed: %s", exc)
    try:
        await client.delete_messages(chat_id, [msg_id])
    except Exception:
        pass


async def _del_code_input_handler(text: str, chat_id: int, msg_id: int, inline_chat_id: int, inline_msg_id: int) -> None:
    from backend.helper.inline_engine import _self_client, _owner_id
    client = _self_client
    owner_id = _owner_id
    code = text.strip().upper()
    result = await _do_del_code(client, owner_id, code)
    builder = InlinePanelBuilder()
    builder.add_row("Close", "panel:help:close")
    try:
        await client.edit_message(inline_chat_id, inline_msg_id, result, buttons=builder.build())
    except Exception as exc:
        logger.warning("del code inline edit failed: %s", exc)
    try:
        await client.delete_messages(chat_id, [msg_id])
    except Exception:
        pass


async def _del_inline_builder(event, extra: str) -> list:
    from telethon.tl import types
    text = "**Delete**\n\nChoose a deletion mode:"
    builder = InlinePanelBuilder()
    builder.add_row("🔢 Delete last N", "input:del:n")
    builder.add_row("🆔 Delete from Msg ID", "input:del:id")
    builder.add_row("📦 Delete saved item", "input:del:code")
    builder.add_row("Close", "panel:help:close")
    buttons = builder.build()
    msg = types.InputBotInlineMessageTextAuto(message=text, reply_markup=types.ReplyInlineMarkup(rows=buttons) if buttons else None)
    result = types.InputBotInlineResult(id="0", type="article", title="Delete Messages", send_message=msg)
    return [result]


def register(client, owner_id: int):
    register_panel("del", _del_inline_builder)
    register_inline_builder("del", _del_inline_builder)
    register_input("del", "n", _del_n_input_handler)
    register_input("del", "id", _del_id_input_handler)
    register_input("del", "code", _del_code_input_handler)

    @client.on(events.NewMessage(outgoing=True, pattern=r"^\.del(?:\s+(.+))?$"))
    async def del_cmd(event):
        if not is_owner(event, owner_id):
            return
        arg = (event.pattern_match.group(1) or "").strip()

        if not arg:
            helper = get_client()
            if helper is None:
                await event.edit("⚠️ Inline mode requires the helper bot (BOT_TOKEN).")
                return
            try:
                await event.delete()
                await send_inline_panel(client, event.chat_id, "del")
            except Exception as exc:
                logger.warning("del inline send failed: %s", exc)
            return

        if arg.lower().startswith("id "):
            rest = arg[3:].strip()
            if not rest.isdigit():
                await event.edit("⚠️ Usage: `.del id <msgid>`")
                return
            await event.delete()
            result = await _do_del_id(client, event.chat_id, int(rest))
            # Result is silent — messages are deleted
            return

        elif arg.isdigit():
            n = int(arg)
            if n < 1 or n > 500:
                await event.edit("⚠️ n must be between 1 and 500.")
                return
            await event.delete()
            result = await _do_del_n(client, event.chat_id, n)
            return

        else:
            code = arg.upper()
            result = await _do_del_code(client, owner_id, code)
            await event.edit(result)
